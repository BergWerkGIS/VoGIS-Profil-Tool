class Raster:
    def __init__(self, id, name, grid):
        self.id = id
        self.name = name
        self.grid = grid
        self.selected = False
