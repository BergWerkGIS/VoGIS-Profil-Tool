class MapData:

    def __init__(self):
        self.rasters = None
        self.lines = None
        self.selectedLineLyr = None
        self.customLine = None
