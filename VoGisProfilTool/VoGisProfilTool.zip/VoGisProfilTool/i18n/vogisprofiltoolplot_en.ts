<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en_GB" sourcelanguage="de_AT">
<context>
    <name>VoGISProfilToolMain</name>
    <message>
        <location filename="ui/ui_vogisprofiltoolmain.py" line="224"/>
        <source>VoGIS Profil Tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="ui/ui_vogisprofiltoolmain.py" line="225"/>
        <source>Rastermodell(e) auswählen</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="ui/ui_vogisprofiltoolmain.py" line="226"/>
        <source>Im aktuellen Extent sichtbare Raster auswählen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_vogisprofiltoolmain.py" line="227"/>
        <source>Raster aktualisieren</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_vogisprofiltoolmain.py" line="228"/>
        <source>Lage der Profillinie(n) festlegen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_vogisprofiltoolmain.py" line="229"/>
        <source>Profillinie (neu) digitalisieren</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_vogisprofiltoolmain.py" line="230"/>
        <source>nur selektierte Elemente verwenden</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_vogisprofiltoolmain.py" line="231"/>
        <source>Linien explodieren (Multipart Features)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="ui/ui_vogisprofiltoolmain.py" line="232"/>
        <source>Profillinie(n) aus Linienthema übernehmen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_vogisprofiltoolmain.py" line="233"/>
        <source>Profillinie am Bildschirm zeichen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_vogisprofiltoolmain.py" line="234"/>
        <source>Linie</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_vogisprofiltoolmain.py" line="235"/>
        <source>.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_vogisprofiltoolmain.py" line="236"/>
        <source>von:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_vogisprofiltoolmain.py" line="237"/>
        <source>nach:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_vogisprofiltoolmain.py" line="238"/>
        <source>Rechtswert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_vogisprofiltoolmain.py" line="239"/>
        <source>Hochwert</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="ui/ui_vogisprofiltoolmain.py" line="240"/>
        <source>Zusammenhängende Linien verbinden</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_vogisprofiltoolmain.py" line="241"/>
        <source>gerade Profillinie zwischen zwei Punkten</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="ui/ui_vogisprofiltoolmain.py" line="242"/>
        <source>Stützstellen festlegen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_vogisprofiltoolmain.py" line="243"/>
        <source>Abstand zwischen den Profilpunkten</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_vogisprofiltoolmain.py" line="244"/>
        <source>Anzahl Profilpunkte pro Profil</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="ui/ui_vogisprofiltoolmain.py" line="245"/>
        <source>Profilpunkte erstellen an Knoten und Stützstellen</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
