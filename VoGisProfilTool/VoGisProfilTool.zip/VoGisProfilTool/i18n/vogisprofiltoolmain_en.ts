<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en_US" sourcelanguage="de_AT">
<context>
    <name>VoGISProfilToolMain</name>
    <message>
        <location filename="ui/ui_vogisprofiltoolmain.py" line="131"/>
        <source>VoGISProfilToolMain</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="ui/ui_vogisprofiltoolmain.py" line="132"/>
        <source>Rastermodell(e) auswählen</source>
        <translation>Choose raster(s)</translation>
    </message>
    <message>
        <location filename="ui/ui_vogisprofiltoolmain.py" line="133"/>
        <source>Lage der Profillinie(n) festlegen</source>
        <translation>Define profile line(s)</translation>
    </message>
    <message utf8="true">
        <location filename="ui/ui_vogisprofiltoolmain.py" line="135"/>
        <source>Profillinie(n) aus Linienthema übernehmen</source>
        <translation>Derive profile from line features</translation>
    </message>
    <message>
        <location filename="ui/ui_vogisprofiltoolmain.py" line="97"/>
        <source>Profillinie digitalisieren</source>
        <translation type="obsolete">Digitize profile</translation>
    </message>
    <message>
        <location filename="ui/ui_vogisprofiltoolmain.py" line="137"/>
        <source>gerade Profillinie zwischen zwei Punkten</source>
        <translation>Straight line between two points</translation>
    </message>
    <message>
        <location filename="ui/ui_vogisprofiltoolmain.py" line="100"/>
        <source>Abstand</source>
        <translation type="obsolete">Distance</translation>
    </message>
    <message>
        <location filename="ui/ui_vogisprofiltoolmain.py" line="101"/>
        <source>Anzahl</source>
        <translation type="obsolete">Number of Vertices</translation>
    </message>
    <message>
        <location filename="ui/ui_vogisprofiltoolmain.py" line="141"/>
        <source>Vertices</source>
        <translation>Vertices</translation>
    </message>
    <message utf8="true">
        <location filename="ui/ui_vogisprofiltoolmain.py" line="139"/>
        <source>Stützstellen festlegen</source>
        <translation>Define vertices</translation>
    </message>
    <message>
        <location filename="ui/ui_vogisprofiltoolmain.py" line="134"/>
        <source>Profillinie am Bildschirm zeichen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_vogisprofiltoolmain.py" line="136"/>
        <source>Profillinie (neu) digitalisieren</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_vogisprofiltoolmain.py" line="138"/>
        <source>nur selektierte Elementer verwenden</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_vogisprofiltoolmain.py" line="140"/>
        <source>Anzahl Profilpunkte pro Profil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/ui_vogisprofiltoolmain.py" line="142"/>
        <source>Abstand zwischen den Profilpunkten</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
